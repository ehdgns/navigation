import React,{Component} from 'react';
import { StyleSheet, Text, TouchableOpacity,View,Button } from 'react-native';
import { TextInput } from 'react-native-gesture-handler';
import MyButton from '../components/MyButton';
export default class BoardCreateScreen extends Component{
    constructor(props)
    {
        super(props)
        this.state= {
            title: '',
            content:''
        }
    }
    submitBoard() {
        const createFunc = this.props.navigation.getParam('createFunc')
        const boardItem = {
            title: this.state.title,
            content: this.state.content
        }
        console.log(createFunc)
        createFunc(boardItem) 
        return this.props.navigation.navigate('Home')
    }
    
    render() {
        return (
       <View> 
       <Text style={{
        color:'blue',
        fontSize:40

    }}>글 작성 스크린</Text>

    <TextInput
    style={{
        borderWidth:1,
        minHeight:20,
        fontSize:50,
        margin:20,
        marginTop:30
    }}
    placeholder="제목"
    onChangeText={(text)=>this.setState({title:text})}
    />
    
 <Text>{this.state.title}</Text>

    <TextInput
    style={{
        borderWidth:1,
        minHeight:300,
        fontSize:20,
        margin:20,
        marginTop:30
    }}
    placeholder="내용"
    onChangeText={(text)=>this.setState({content:text})}
    />
 <Text>{this.state.content}</Text>
 
<MyButton title="제출하기" onPress={this.submitBoard.bind(this)}/> 
       </View>
           
     
       
    )
}}