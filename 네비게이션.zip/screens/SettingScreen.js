import React,{Component} from 'react';
import { StyleSheet, Text, TouchableOpacity,View } from 'react-native';

export default class settingScreen extends Component{
    render() {
        return(
            <View style={{flex: 1, alignItems: 'center', justifyContent:'center'}}>
            <Text style={styles.style1}>Setting을 위한 스크린!</Text>

      </View>
            
        )
    }
}

const styles = StyleSheet.create({

    style1: {
        fontSize: 30,
        color: 'red',
    }
})
