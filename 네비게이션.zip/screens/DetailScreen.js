import React, {Component} from 'react';
import {View, Text, StyleSheet} from 'react-native';

export default class DetailScreen extends Component{
    constructor(props){
        super(props)
        const item = this.props.navigation.getParam('item')
        console.log(item)
    }
    render() {
        return (
            <View>
                <Text style={{
                    fontSize: 30,
                    fontWeight:'bold'
                }}>
                    상세 페이지!
                </Text>
                <Text style={styles.title}>{this.props.navigation.getParam('item').title}</Text>

                <Text style={styles.content}>{this.props.navigation.getParam('item').content}</Text>
              {/* <TouchableOpacity onPress={()=>this.props.navigation.navigate("Edit")}>
                  <Text>수정</Text>
              </TouchableOpacity> */}
            </View>
        );
    }
}

const styles = StyleSheet.create({
    title:{
        fontSize:30,
        margin: 20,
        fontWeight:'900'
    },
    content:{
        fontSize: 20,
        margin: 20
    }
})




/* import React,{Component} from 'react';
import { StyleSheet, Text, TouchableOpacity,View } from 'react-native';

export default class DetailScreen extends Component{
    render() {
        return(
            <View style={{flex: 1, alignItems: 'center'}}>
            <Text style={styles.style1}>상세 스크린!</Text>

            <TouchableOpacity 
            onPress={()=>this.props.navigation.push('Detail')}>
                <Text style={{fontWeight:'bold', fontSize: 30, color:'blue'}}>디테일의 디테일 가기 </Text></TouchableOpacity> 
            
            <TouchableOpacity
              onPress={()=>this.props.navigation.goBack()}>
                  <Text style={{fontWeight:'bold', fontSize: 30, color:'purple'}}>뒤로 가기 </Text></TouchableOpacity> 
            
            <TouchableOpacity
              onPress={()=>this.props.navigation.popToTop()}
            ><Text style={{fontWeight:'bold', fontSize: 30, color:'red'}}>처음으로 가기 </Text></TouchableOpacity> 
            </View>
            
        )
    }
}

const styles = StyleSheet.create({

    style1: {
        fontSize: 40,
        color: 'black',
    }
})
 */