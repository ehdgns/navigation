import React,{Component} from 'react';
import { StyleSheet, Text, TouchableOpacity,View } from 'react-native';

export default class MyButton extends Component{
    render(){
        return(
            <View>
                <TouchableOpacity 
                onPress={this.props.onPress}>
                <Text style=
                {{backgroundColor:'tomato',
                fontSize:22,
                padding: 10,
                color: 'white',
                fontWeight: "bold",
                width:80,
                height:50

            }}>
                글 작성</Text>
                </TouchableOpacity>
                </View>
        )
    }
}