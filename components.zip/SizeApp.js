import React ,{Component} from 'react';
import {View, Text} from 'react-native';

export default class SizeApp extends Component{
    render(){
        return (
            <View>
                <View style={{backgroundColor: 'blue', width:50, height:50}}></View>
                <Text>50*50</Text>
                <View style={{backgroundColor: 'black', width:100, height:100}}></View>
                <Text>100*100</Text>
                <View style={{backgroundColor: 'red', width:150, height:150}}></View>
                <Text>150*150</Text>
            </View>
        )
    }
}
