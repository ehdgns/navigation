import React,{Component} from 'react';
import {View, Text, StyleSheet} from 'react-native';

export default class StyleApp extends Component{
    render(){
        let red_color = {
            color: 'red'
        }
        return (
            <View>
                {/* 1라인으로 준다. */}
                <Text style={{color:'red'}}>just red</Text>
                {/* jsx에서 중괄호 쓰는 이유 -> 자바스크립트 코드를 실행하겠다. */}
                <Text style={red_color}>just red</Text>
                <Text style={styles.bigblue}>just bigblue</Text>
                {/* 대괄호 -> 리스트로 선언한다. */}
                <Text style={[styles.bigblue, styles.red]}>bigblue, then red</Text>
                <Text style={[styles.red, styles.bigblue]}>red, then bigblue</Text>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    bigblue : {
        color: 'blue',
        fontWeight: 'bold',
        fontSize: 30,
    },
    red: {
        color: 'red',
    },
});