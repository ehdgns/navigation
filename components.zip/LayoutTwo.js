import React,{Component} from 'react';
import {View} from 'react-native';

export default class FlexDimensionsBasics extends Component{
    render(){
        return(
            <View style={{flex: 1, width:'100%',flexDirection:'column'}}>
                <View style={{flex: 2, backgroundColor: 'red'}}/>
                <View style={{flex: 3, backgroundColor: 'white'}}/>
                <View style={{flex: 4, backgroundColor: 'blue'}}/>
                <View style={{flex: 1, backgroundColor: 'green', flexDirection:'row'}}/>
            </View>
        );
    }
};