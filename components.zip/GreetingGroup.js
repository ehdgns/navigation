import React,{Component} from 'react';
import {View, Text} from 'react-native';

import Greeting from './Greeting';

export default class GreetingGroup extends Component{
    render(){
        return(
        <View>
            <Greeting name="jyw"/>
            <Greeting name="jyh"/>
            <Greeting name="kyh"/>     
        </View>
        )
    }
}