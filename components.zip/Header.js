import React,{Components} from 'react';
import {Text} from 'react-native';

export default class Header extends Component{
    render(){
        return(
            <Text style={[{fontSize:40, fontWeight:'bold'}, this.props.style]}>
                {this.props.children}
            </Text>
        )
    }

}

