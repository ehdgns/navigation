import React,{Component} from 'react';
import {View, Text, Image} from 'react-native';

export default class BaseTextInput extends Component{
    constructor(props){
        super(props);
        this.state - {text: 'BaseText input입니다.'};
    }
    render() {
        return(
            <TextInput 
                style={{height:40, width:"80%", borderColor: 'gray', borderWidth: 1}} 
                onChangeText={(text) => this.setState({text})} value={this.state.text}/>
        );
    }
}